# Silo Yamtrack watch-sync plugin

This project contains both the read-only diagnostic utility and the Silo watch-sync provider. It connects to Yamtrack's PostgreSQL database, verifies the v0.25.3 columns used by the adapter, and normalizes completed movies and watched episodes for one Yamtrack user. It contains no `INSERT`, `UPDATE`, or `DELETE` statements.

The normalized output includes:

- TMDB movie IDs;
- TMDB series IDs plus season and episode numbers;
- play counts and rewatches;
- the most recent watch timestamp;
- every available watch timestamp in JSON output.

The Silo provider is pinned to `silo-plugin-sdk` v0.13.0 and advertises only watched-state import for movies and episodes. Export, unwatch, progress, favorites, watchlists, and playback scrobbling are disabled.

## 1. Create the read-only PostgreSQL role

Edit `sql/create-readonly-role.sql`, replace `CHANGE_ME` with a new strong password, and run:

```bash
docker exec -i yamtrack-db \
  psql -U yamtrack -d yamtrack \
  < sql/create-readonly-role.sql
```

The role receives only `CONNECT`, schema `USAGE`, and `SELECT` on the four Yamtrack tables used by this bootstrap. Do not add write grants.

If the role already exists, rotate its password instead of re-running `CREATE ROLE`:

```sql
ALTER ROLE silo_sync WITH PASSWORD 'A_NEW_STRONG_PASSWORD';
```

## 2. Confirm the user ID and network

The diagnostic defaults to Yamtrack user ID `1`. To check it:

```sql
SELECT user_id, COUNT(*) AS tracked_rows
FROM (
  SELECT user_id FROM app_movie
  UNION ALL
  SELECT user_id FROM app_season
) x
GROUP BY user_id
ORDER BY tracked_rows DESC;
```

Confirm the Docker network attached to Yamtrack:

```bash
docker inspect yamtrack-db \
  --format '{{json .NetworkSettings.Networks}}'
```

For the deployment this bootstrap was prepared for, the actual external network name is `yamtrack` (not `yamtrack_yamtrack`). Both `.env.example` and `compose.example.yml` therefore default to `yamtrack`.

## 3. Build and run

Set the password without committing it to a file:

```bash
export YAMTRACK_SYNC_DB_PASSWORD='THE_PASSWORD_FOR_silo_sync'
export YAMTRACK_DOCKER_NETWORK='yamtrack'
```

If your Yamtrack user ID is not `1`, change `YAMTRACK_USER_ID` in `compose.example.yml`. Then:

```bash
docker compose -f compose.example.yml build
docker compose -f compose.example.yml run --rm yamtrack-sync-diagnose
```

The report prints aggregate counts followed by the ten most recent movies and episodes. Use `--limit` to change the number of samples:

```bash
docker compose -f compose.example.yml run --rm \
  yamtrack-sync-diagnose --limit 25
```

To emit JSON:

```bash
docker compose -f compose.example.yml run --rm \
  yamtrack-sync-diagnose --json \
  > yamtrack-watch-state.json
```

The JSON is the complete normalized dataset rather than only the displayed samples. Records whose source is not TMDB are counted in `unsupported_movies` or `unsupported_episodes` and deliberately omitted from Silo-ready records.

## Validate the result

Before adding the Silo provider, compare the report with Yamtrack:

1. Check the unique movie and episode totals.
2. Find a movie with `plays` greater than one and confirm its rewatch count.
3. Find an episode with `plays` greater than one, if you have one.
4. Spot-check several TMDB IDs and SxxExx coordinates.
5. Spot-check recent timestamps. A value of `unknown` means Yamtrack stored no `end_date`; the adapter does not invent one.

The total tracked movie/season count from the bootstrap connection check will not equal the normalized watch counts. It includes season rows and non-completed states, while this report emits completed movies and individual episode-watch rows.

## Troubleshooting

### `missing go.sum entry for module providing package github.com/jackc/pgx/v5/stdlib`

This means the source bundle lacks the checksums needed to build the pinned PostgreSQL driver. The updated bundle includes `go.sum`, and the Dockerfile copies both module files before running `go mod download`.

After replacing the old project directory with this bundle, rebuild without relying on the failed image layer:

```bash
docker compose -f compose.example.yml build --no-cache
```

Do not generate a different dependency set inside the production container; `go.mod` and `go.sum` should stay together in source control and in the zip.

### `network yamtrack_yamtrack declared as external, but could not be found`

The Compose project label is not necessarily the Docker network's real name. Inspect `yamtrack-db` as shown above and use the key in the returned JSON. For this deployment it is `yamtrack`:

```bash
export YAMTRACK_DOCKER_NETWORK='yamtrack'
docker network inspect yamtrack
docker compose -f compose.example.yml run --rm yamtrack-sync-diagnose
```

If the inspect command reports a different network, export that exact name. Because the network is declared `external`, this Compose file will never create or rename it.

### Authentication fails after the role was created

Make sure the exported password matches the current `silo_sync` password. If a password appeared in terminal output or chat, rotate it with `ALTER ROLE` and update the exported value. The role remains read-only, but rotation is still appropriate.

### Permission denied for a Yamtrack table

Re-run only the `GRANT CONNECT`, `GRANT USAGE`, and `GRANT SELECT` statements in `sql/create-readonly-role.sql` as the Yamtrack database owner. Do not grant write privileges.

## Safety boundary

- Yamtrack is authoritative.
- The `silo_sync` role has no table write privileges.
- The Go adapter issues only information-schema checks and `SELECT` queries.
- The provider returns desired watched state through Silo's plugin API; it never writes directly to Silo's database.
- The read-only database password is entered as the profile's provider API key. Silo encrypts it; the plugin uses it transiently for each RPC and does not put it in global plugin configuration.

## Silo provider installation

The release contains a Silo upload archive for each Linux architecture:

- `silo-yamtrack-watchsync-linux-amd64.zip` for `x86_64` hosts;
- `silo-yamtrack-watchsync-linux-arm64.zip` for `aarch64`/`arm64` hosts.

Check the Docker host architecture with:

```bash
uname -m
```

Upload the matching zip under Silo's Admin plugin page. Each archive has exactly the layout Silo expects:

```text
manifest.json
plugin
```

The manifest checksum is generated from that exact binary.

### Connect Silo to the Yamtrack network

The plugin runs inside Silo's container network namespace. Add the existing external `yamtrack` network to the Silo service in Silo's Compose file so the connection survives container recreation:

```yaml
services:
  silo:
    networks:
      - default
      - yamtrack

networks:
  yamtrack:
    external: true
    name: yamtrack
```

Use your actual Silo service name in place of `silo`. As a temporary connectivity test, you can attach the running container directly:

```bash
docker network connect yamtrack YOUR_SILO_CONTAINER
```

Docker reports an error if it is already attached; that is harmless. The Compose configuration is the durable solution.

### Configure the plugin

In the installed plugin's administrative configuration, use:

```text
Host:                    yamtrack-db
Port:                    5432
Database:                yamtrack
Read-only database user: silo_sync
SSL mode:                disable
Yamtrack user ID:        1
```

Do not place the PostgreSQL password in these settings.

### Connect your Silo profile

Open the profile's Watch Providers settings and select Yamtrack. Silo labels the connection field `API key`; for this local provider, paste the password for the read-only `silo_sync` PostgreSQL role. The plugin validates the password, expected schema, and Yamtrack user before accepting the connection.

The first sync is a complete snapshot. With the validated library in this deployment, Silo will traverse roughly 222 pages of at most 100 items each. Page tokens use a fixed timestamp and keyset pagination so watches added during the traversal do not shift later pages.

If the connection fails, verify that the Silo container can resolve `yamtrack-db` on the `yamtrack` network and that the role still has only the grants from `sql/create-readonly-role.sql`.

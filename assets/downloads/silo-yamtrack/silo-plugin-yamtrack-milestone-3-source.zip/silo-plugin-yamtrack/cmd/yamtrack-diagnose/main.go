package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"os"
	"time"

	"github.com/example/silo-plugin-yamtrack/internal/yamtrack"
)

func main() {
	jsonOutput := flag.Bool("json", false, "write the complete normalized watch state as JSON")
	limit := flag.Int("limit", 10, "number of recent movies and episodes to print (0 prints none)")
	flag.Parse()
	if *limit < 0 {
		log.Fatal("--limit cannot be negative")
	}

	cfg, err := yamtrack.ConfigFromEnv()
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	store, err := yamtrack.Open(ctx, cfg)
	if err != nil {
		log.Fatal(err)
	}
	defer store.Close()
	if err := store.VerifySchema(ctx); err != nil {
		log.Fatal(err)
	}
	state, err := store.WatchState(ctx, cfg.UserID)
	if err != nil {
		log.Fatal(err)
	}
	if *jsonOutput {
		encoder := json.NewEncoder(os.Stdout)
		encoder.SetIndent("", "  ")
		if err := encoder.Encode(state); err != nil {
			log.Fatal(err)
		}
		return
	}

	fmt.Println("Connected to Yamtrack PostgreSQL ✓")
	fmt.Println("Schema matches Yamtrack v0.25.3 expectations ✓")
	fmt.Printf("Yamtrack user ID: %d ✓\n\n", cfg.UserID)
	fmt.Printf("Movies:   %d unique watched, %d total plays, %d rewatches\n", state.Summary.Movies.Unique, state.Summary.Movies.TotalPlays, state.Summary.Movies.Rewatches)
	fmt.Printf("Episodes: %d unique watched, %d total plays, %d rewatches\n", state.Summary.Episodes.Unique, state.Summary.Episodes.TotalPlays, state.Summary.Episodes.Rewatches)
	if state.Summary.UnsupportedMovies+state.Summary.UnsupportedEpisodes > 0 {
		fmt.Printf("Skipped:  %d movie rows and %d episode rows without supported TMDB identity\n", state.Summary.UnsupportedMovies, state.Summary.UnsupportedEpisodes)
	}

	printMovies(state.Movies, *limit)
	printEpisodes(state.Episodes, *limit)
}

func printMovies(movies []yamtrack.MovieWatch, limit int) {
	if limit > len(movies) {
		limit = len(movies)
	}
	fmt.Printf("\nRecent movies (up to %d)\n", limit)
	for _, movie := range movies[:limit] {
		fmt.Printf("  %s  TMDB=%s  plays=%d  last=%s\n", movie.Title, movie.TMDBID, movie.PlayCount, formatTime(movie.LastWatched))
	}
}

func printEpisodes(episodes []yamtrack.EpisodeWatch, limit int) {
	if limit > len(episodes) {
		limit = len(episodes)
	}
	fmt.Printf("\nRecent episodes (up to %d)\n", limit)
	for _, episode := range episodes[:limit] {
		fmt.Printf("  %s  S%02dE%02d  TMDB=%s  plays=%d  last=%s\n", episode.SeriesTitle, episode.SeasonNumber, episode.EpisodeNumber, episode.SeriesTMDBID, episode.PlayCount, formatTime(episode.LastWatched))
	}
}

func formatTime(value *time.Time) string {
	if value == nil {
		return "unknown"
	}
	return value.Format(time.RFC3339)
}

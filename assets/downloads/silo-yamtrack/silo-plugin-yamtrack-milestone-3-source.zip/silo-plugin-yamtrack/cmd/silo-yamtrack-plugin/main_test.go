package main

import (
	"testing"

	pluginv1 "github.com/Silo-Server/silo-plugin-sdk/pkg/pluginproto/silo/plugin/v1"
	publicmanifest "github.com/Silo-Server/silo-plugin-sdk/pkg/pluginsdk/manifest"
)

func TestEmbeddedManifest(t *testing.T) {
	manifest, err := publicmanifest.LoadWithChecksum(manifestJSON, "0.2.0")
	if err != nil {
		t.Fatal(err)
	}
	if manifest.GetPluginId() != "community.yamtrack.watchsync" {
		t.Fatalf("plugin ID = %q", manifest.GetPluginId())
	}
	if len(manifest.GetCapabilities()) != 1 {
		t.Fatalf("capabilities = %d, want 1", len(manifest.GetCapabilities()))
	}
	descriptor := manifest.GetCapabilities()[0].GetWatchSyncProvider()
	if descriptor == nil || !descriptor.GetImportWatched() {
		t.Fatal("watched import must be enabled")
	}
	if descriptor.GetExportWatched() || descriptor.GetExportUnwatched() || descriptor.GetImportProgress() {
		t.Fatalf("unsafe or unsupported capabilities advertised: %+v", descriptor)
	}
	if got := descriptor.GetSupportedMediaTypes(); len(got) != 2 ||
		got[0] != pluginv1.WatchSyncMediaType_WATCH_SYNC_MEDIA_TYPE_MOVIE ||
		got[1] != pluginv1.WatchSyncMediaType_WATCH_SYNC_MEDIA_TYPE_EPISODE {
		t.Fatalf("supported media = %v", got)
	}
}

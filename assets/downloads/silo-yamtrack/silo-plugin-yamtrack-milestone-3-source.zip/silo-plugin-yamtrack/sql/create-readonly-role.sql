-- Run as the Yamtrack PostgreSQL owner/admin.
-- Replace CHANGE_ME with a strong generated password before executing.

CREATE ROLE silo_sync WITH LOGIN PASSWORD 'CHANGE_ME';
GRANT CONNECT ON DATABASE yamtrack TO silo_sync;
GRANT USAGE ON SCHEMA public TO silo_sync;
GRANT SELECT ON TABLE
    public.app_item,
    public.app_movie,
    public.app_season,
    public.app_episode
TO silo_sync;

-- Intentionally NO INSERT / UPDATE / DELETE grants.

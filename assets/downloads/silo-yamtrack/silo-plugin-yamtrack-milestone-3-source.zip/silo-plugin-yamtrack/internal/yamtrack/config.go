package yamtrack

import (
	"fmt"
	"os"
	"strconv"
)

type Config struct {
	Host     string
	Port     int
	Database string
	User     string
	Password string
	SSLMode  string
	UserID   int64
}

func ConfigFromEnv() (Config, error) {
	port, err := envInt("YAMTRACK_DB_PORT", 5432)
	if err != nil {
		return Config{}, err
	}
	userID, err := envInt64("YAMTRACK_USER_ID", 1)
	if err != nil {
		return Config{}, err
	}
	cfg := Config{
		Host:     envOr("YAMTRACK_DB_HOST", "yamtrack-db"),
		Port:     port,
		Database: envOr("YAMTRACK_DB_NAME", "yamtrack"),
		User:     envOr("YAMTRACK_DB_USER", "silo_sync"),
		Password: os.Getenv("YAMTRACK_DB_PASSWORD"),
		SSLMode:  envOr("YAMTRACK_DB_SSLMODE", "disable"),
		UserID:   userID,
	}
	if cfg.Password == "" {
		return Config{}, fmt.Errorf("YAMTRACK_DB_PASSWORD is required")
	}
	return cfg, nil
}

func (c Config) DSN() string {
	return fmt.Sprintf("host=%s port=%d dbname=%s user=%s password=%s sslmode=%s", c.Host, c.Port, c.Database, c.User, c.Password, c.SSLMode)
}

func envOr(key, fallback string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return fallback
}

func envInt(key string, fallback int) (int, error) {
	value := os.Getenv(key)
	if value == "" {
		return fallback, nil
	}
	parsed, err := strconv.Atoi(value)
	if err != nil {
		return 0, fmt.Errorf("%s must be an integer: %w", key, err)
	}
	return parsed, nil
}

func envInt64(key string, fallback int64) (int64, error) {
	value := os.Getenv(key)
	if value == "" {
		return fallback, nil
	}
	parsed, err := strconv.ParseInt(value, 10, 64)
	if err != nil {
		return 0, fmt.Errorf("%s must be an integer: %w", key, err)
	}
	return parsed, nil
}

package yamtrack

import (
	"database/sql"
	"testing"
	"time"
)

func TestAggregateMovies(t *testing.T) {
	older := time.Date(2026, 1, 2, 3, 4, 0, 0, time.UTC)
	newer := older.Add(24 * time.Hour)
	rows := []movieRow{
		{TMDBID: "550", Title: "Fight Club", Watched: sql.NullTime{Time: newer, Valid: true}},
		{TMDBID: "550", Title: "Fight Club", Watched: sql.NullTime{Time: older, Valid: true}},
		{TMDBID: "238", Title: "The Godfather"},
	}

	got := aggregateMovies(rows)
	if len(got) != 2 {
		t.Fatalf("got %d movies, want 2", len(got))
	}
	if got[0].TMDBID != "550" || got[0].PlayCount != 2 {
		t.Fatalf("unexpected first movie: %+v", got[0])
	}
	if got[0].LastWatched == nil || !got[0].LastWatched.Equal(newer) {
		t.Fatalf("last watched = %v, want %v", got[0].LastWatched, newer)
	}
	if len(got[0].WatchDates) != 2 || !got[0].WatchDates[0].Equal(older) {
		t.Fatalf("watch dates not sorted: %v", got[0].WatchDates)
	}
}

func TestAggregateEpisodes(t *testing.T) {
	when := time.Date(2026, 2, 3, 4, 5, 0, 0, time.UTC)
	rows := []episodeRow{
		{SeriesTMDBID: "1396", SeriesTitle: "Breaking Bad", SeasonNumber: 3, EpisodeNumber: 7, Watched: sql.NullTime{Time: when, Valid: true}},
		{SeriesTMDBID: "1396", SeriesTitle: "Breaking Bad", SeasonNumber: 3, EpisodeNumber: 7},
		{SeriesTMDBID: "1396", SeriesTitle: "Breaking Bad", SeasonNumber: 3, EpisodeNumber: 8},
	}

	got := aggregateEpisodes(rows)
	if len(got) != 2 {
		t.Fatalf("got %d episodes, want 2", len(got))
	}
	if got[0].EpisodeNumber != 7 || got[0].PlayCount != 2 {
		t.Fatalf("unexpected first episode: %+v", got[0])
	}
}

func TestStats(t *testing.T) {
	got := stats(8, 11)
	if got.Unique != 8 || got.TotalPlays != 11 || got.Rewatches != 3 {
		t.Fatalf("unexpected stats: %+v", got)
	}
}

package yamtrack

import (
	"context"
	"database/sql"
	"fmt"
	"time"
)

const MaxRemotePageSize = 100

type RemoteWatch struct {
	ProviderItemKey string
	MediaType       string
	TMDBID          string
	Title           string
	SeasonNumber    int
	EpisodeNumber   int
	PlayCount       int64
	LastWatched     *time.Time
}

func (s *Store) ValidateUser(ctx context.Context, userID int64) error {
	const query = `
		SELECT EXISTS (
			SELECT 1 FROM public.app_movie WHERE user_id = $1
			UNION ALL
			SELECT 1 FROM public.app_season WHERE user_id = $1
		)`
	var exists bool
	if err := s.db.QueryRowContext(ctx, query, userID).Scan(&exists); err != nil {
		return fmt.Errorf("check Yamtrack user: %w", err)
	}
	if !exists {
		return fmt.Errorf("Yamtrack user ID %d has no tracked media", userID)
	}
	return nil
}

// WatchedPage returns a stable keyset page from a full snapshot bounded by
// cutoff. It issues only SELECT statements. Callers request limit+1 so they can
// determine whether another page exists without a separate count query.
func (s *Store) WatchedPage(
	ctx context.Context,
	userID int64,
	cutoff time.Time,
	afterKey string,
	limit int,
) ([]RemoteWatch, error) {
	if limit < 1 || limit > MaxRemotePageSize+1 {
		return nil, fmt.Errorf("remote page size must be between 1 and %d", MaxRemotePageSize+1)
	}
	const query = `
		WITH remote_watches AS (
			SELECT
				'movie:tmdb:' || i.media_id AS provider_item_key,
				'movie'::text AS media_type,
				i.media_id AS tmdb_id,
				MAX(i.title) AS title,
				0::integer AS season_number,
				0::integer AS episode_number,
				COUNT(*)::bigint AS play_count,
				MAX(m.end_date) AS last_watched
			FROM public.app_movie m
			JOIN public.app_item i ON i.id = m.item_id
			WHERE m.user_id = $1
			  AND m.created_at <= $2
			  AND m.status = 'Completed'
			  AND i.source = 'tmdb'
			  AND i.media_type = 'movie'
			GROUP BY i.media_id

			UNION ALL

			SELECT
				'episode:tmdb:' || i.media_id || ':' || i.season_number || ':' || i.episode_number AS provider_item_key,
				'episode'::text AS media_type,
				i.media_id AS tmdb_id,
				MAX(i.title) AS title,
				i.season_number,
				i.episode_number,
				COUNT(*)::bigint AS play_count,
				MAX(e.end_date) AS last_watched
			FROM public.app_episode e
			JOIN public.app_item i ON i.id = e.item_id
			JOIN public.app_season s ON s.id = e.related_season_id
			WHERE s.user_id = $1
			  AND e.created_at <= $2
			  AND i.source = 'tmdb'
			  AND i.media_type = 'episode'
			GROUP BY i.media_id, i.season_number, i.episode_number
		)
		SELECT provider_item_key, media_type, tmdb_id, title,
		       season_number, episode_number, play_count, last_watched
		FROM remote_watches
		WHERE provider_item_key > $3
		ORDER BY provider_item_key
		LIMIT $4`

	rows, err := s.db.QueryContext(ctx, query, userID, cutoff, afterKey, limit)
	if err != nil {
		return nil, fmt.Errorf("read paged Yamtrack watch state: %w", err)
	}
	defer rows.Close()

	result := make([]RemoteWatch, 0, limit)
	for rows.Next() {
		var watch RemoteWatch
		var lastWatched sql.NullTime
		if err := rows.Scan(
			&watch.ProviderItemKey,
			&watch.MediaType,
			&watch.TMDBID,
			&watch.Title,
			&watch.SeasonNumber,
			&watch.EpisodeNumber,
			&watch.PlayCount,
			&lastWatched,
		); err != nil {
			return nil, fmt.Errorf("scan paged Yamtrack watch state: %w", err)
		}
		if lastWatched.Valid {
			value := lastWatched.Time
			watch.LastWatched = &value
		}
		result = append(result, watch)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate paged Yamtrack watch state: %w", err)
	}
	return result, nil
}

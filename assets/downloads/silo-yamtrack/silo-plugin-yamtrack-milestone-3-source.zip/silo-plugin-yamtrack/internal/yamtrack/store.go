package yamtrack

import (
	"context"
	"database/sql"
	"fmt"
	"sort"
	"time"

	_ "github.com/jackc/pgx/v5/stdlib"
)

var requiredColumns = map[string][]string{
	"app_item":    {"id", "media_id", "source", "media_type", "title", "season_number", "episode_number"},
	"app_movie":   {"id", "item_id", "user_id", "status", "end_date", "created_at"},
	"app_season":  {"id", "item_id", "user_id", "related_tv_id"},
	"app_episode": {"id", "item_id", "related_season_id", "end_date", "created_at"},
}

type Store struct {
	db *sql.DB
}

type Stats struct {
	Unique     int `json:"unique"`
	TotalPlays int `json:"total_plays"`
	Rewatches  int `json:"rewatches"`
}

type Summary struct {
	Movies              Stats `json:"movies"`
	Episodes            Stats `json:"episodes"`
	UnsupportedMovies   int   `json:"unsupported_movies"`
	UnsupportedEpisodes int   `json:"unsupported_episodes"`
}

type MovieWatch struct {
	TMDBID      string      `json:"tmdb_id"`
	Title       string      `json:"title"`
	PlayCount   int         `json:"play_count"`
	LastWatched *time.Time  `json:"last_watched_at,omitempty"`
	WatchDates  []time.Time `json:"watch_dates,omitempty"`
}

type EpisodeWatch struct {
	SeriesTMDBID  string      `json:"series_tmdb_id"`
	SeriesTitle   string      `json:"series_title"`
	SeasonNumber  int         `json:"season_number"`
	EpisodeNumber int         `json:"episode_number"`
	PlayCount     int         `json:"play_count"`
	LastWatched   *time.Time  `json:"last_watched_at,omitempty"`
	WatchDates    []time.Time `json:"watch_dates,omitempty"`
}

type WatchState struct {
	UserID      int64          `json:"user_id"`
	GeneratedAt time.Time      `json:"generated_at"`
	Summary     Summary        `json:"summary"`
	Movies      []MovieWatch   `json:"movies"`
	Episodes    []EpisodeWatch `json:"episodes"`
}

type movieRow struct {
	TMDBID  string
	Title   string
	Watched sql.NullTime
}

type episodeRow struct {
	SeriesTMDBID  string
	SeriesTitle   string
	SeasonNumber  int
	EpisodeNumber int
	Watched       sql.NullTime
}

func Open(ctx context.Context, cfg Config) (*Store, error) {
	db, err := sql.Open("pgx", cfg.DSN())
	if err != nil {
		return nil, fmt.Errorf("open PostgreSQL: %w", err)
	}
	ctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()
	if err := db.PingContext(ctx); err != nil {
		db.Close()
		return nil, fmt.Errorf("connect to PostgreSQL: %w", err)
	}
	return &Store{db: db}, nil
}

func (s *Store) Close() error { return s.db.Close() }

func (s *Store) VerifySchema(ctx context.Context) error {
	for table, columns := range requiredColumns {
		for _, column := range columns {
			var exists bool
			const query = `
				SELECT EXISTS (
					SELECT 1 FROM information_schema.columns
					WHERE table_schema = 'public' AND table_name = $1 AND column_name = $2
				)`
			if err := s.db.QueryRowContext(ctx, query, table, column).Scan(&exists); err != nil {
				return fmt.Errorf("check column public.%s.%s: %w", table, column, err)
			}
			if !exists {
				return fmt.Errorf("required Yamtrack column public.%s.%s was not found", table, column)
			}
		}
	}
	return nil
}

func (s *Store) WatchState(ctx context.Context, userID int64) (WatchState, error) {
	movies, err := s.movieRows(ctx, userID)
	if err != nil {
		return WatchState{}, err
	}
	episodes, err := s.episodeRows(ctx, userID)
	if err != nil {
		return WatchState{}, err
	}
	unsupportedMovies, err := s.unsupportedMovies(ctx, userID)
	if err != nil {
		return WatchState{}, err
	}
	unsupportedEpisodes, err := s.unsupportedEpisodes(ctx, userID)
	if err != nil {
		return WatchState{}, err
	}

	state := WatchState{
		UserID:      userID,
		GeneratedAt: time.Now().UTC(),
		Movies:      aggregateMovies(movies),
		Episodes:    aggregateEpisodes(episodes),
	}
	state.Summary = Summary{
		Movies:              stats(len(state.Movies), len(movies)),
		Episodes:            stats(len(state.Episodes), len(episodes)),
		UnsupportedMovies:   unsupportedMovies,
		UnsupportedEpisodes: unsupportedEpisodes,
	}
	return state, nil
}

func (s *Store) movieRows(ctx context.Context, userID int64) ([]movieRow, error) {
	const query = `
		SELECT i.media_id, i.title, m.end_date
		FROM public.app_movie m
		JOIN public.app_item i ON i.id = m.item_id
		WHERE m.user_id = $1
		  AND m.status = 'Completed'
		  AND i.source = 'tmdb'
		  AND i.media_type = 'movie'
		ORDER BY m.end_date DESC NULLS LAST, m.created_at DESC, m.id DESC`
	rows, err := s.db.QueryContext(ctx, query, userID)
	if err != nil {
		return nil, fmt.Errorf("read completed Yamtrack movies: %w", err)
	}
	defer rows.Close()

	var result []movieRow
	for rows.Next() {
		var row movieRow
		if err := rows.Scan(&row.TMDBID, &row.Title, &row.Watched); err != nil {
			return nil, fmt.Errorf("scan Yamtrack movie: %w", err)
		}
		result = append(result, row)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate Yamtrack movies: %w", err)
	}
	return result, nil
}

func (s *Store) episodeRows(ctx context.Context, userID int64) ([]episodeRow, error) {
	const query = `
		SELECT i.media_id, i.title, i.season_number, i.episode_number, e.end_date
		FROM public.app_episode e
		JOIN public.app_item i ON i.id = e.item_id
		JOIN public.app_season s ON s.id = e.related_season_id
		WHERE s.user_id = $1
		  AND i.source = 'tmdb'
		  AND i.media_type = 'episode'
		ORDER BY e.end_date DESC NULLS LAST, e.created_at DESC, e.id DESC`
	rows, err := s.db.QueryContext(ctx, query, userID)
	if err != nil {
		return nil, fmt.Errorf("read watched Yamtrack episodes: %w", err)
	}
	defer rows.Close()

	var result []episodeRow
	for rows.Next() {
		var row episodeRow
		if err := rows.Scan(&row.SeriesTMDBID, &row.SeriesTitle, &row.SeasonNumber, &row.EpisodeNumber, &row.Watched); err != nil {
			return nil, fmt.Errorf("scan Yamtrack episode: %w", err)
		}
		result = append(result, row)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate Yamtrack episodes: %w", err)
	}
	return result, nil
}

func (s *Store) unsupportedMovies(ctx context.Context, userID int64) (int, error) {
	const query = `
		SELECT COUNT(*)
		FROM public.app_movie m
		JOIN public.app_item i ON i.id = m.item_id
		WHERE m.user_id = $1 AND m.status = 'Completed'
		  AND NOT (i.source = 'tmdb' AND i.media_type = 'movie')`
	var count int
	if err := s.db.QueryRowContext(ctx, query, userID).Scan(&count); err != nil {
		return 0, fmt.Errorf("count completed movies without TMDB identity: %w", err)
	}
	return count, nil
}

func (s *Store) unsupportedEpisodes(ctx context.Context, userID int64) (int, error) {
	const query = `
		SELECT COUNT(*)
		FROM public.app_episode e
		JOIN public.app_item i ON i.id = e.item_id
		JOIN public.app_season s ON s.id = e.related_season_id
		WHERE s.user_id = $1
		  AND NOT (i.source = 'tmdb' AND i.media_type = 'episode')`
	var count int
	if err := s.db.QueryRowContext(ctx, query, userID).Scan(&count); err != nil {
		return 0, fmt.Errorf("count episodes without TMDB identity: %w", err)
	}
	return count, nil
}

func stats(unique, total int) Stats {
	return Stats{Unique: unique, TotalPlays: total, Rewatches: total - unique}
}

func aggregateMovies(rows []movieRow) []MovieWatch {
	byID := make(map[string]*MovieWatch)
	for _, row := range rows {
		watch, ok := byID[row.TMDBID]
		if !ok {
			watch = &MovieWatch{TMDBID: row.TMDBID, Title: row.Title}
			byID[row.TMDBID] = watch
		}
		watch.PlayCount++
		if row.Watched.Valid {
			watch.WatchDates = append(watch.WatchDates, row.Watched.Time)
			if watch.LastWatched == nil || row.Watched.Time.After(*watch.LastWatched) {
				value := row.Watched.Time
				watch.LastWatched = &value
			}
		}
	}
	result := make([]MovieWatch, 0, len(byID))
	for _, watch := range byID {
		sort.Slice(watch.WatchDates, func(i, j int) bool { return watch.WatchDates[i].Before(watch.WatchDates[j]) })
		result = append(result, *watch)
	}
	sort.Slice(result, func(i, j int) bool {
		return moreRecent(result[i].LastWatched, result[j].LastWatched, result[i].Title, result[j].Title)
	})
	return result
}

func aggregateEpisodes(rows []episodeRow) []EpisodeWatch {
	byID := make(map[string]*EpisodeWatch)
	for _, row := range rows {
		key := fmt.Sprintf("%s:%d:%d", row.SeriesTMDBID, row.SeasonNumber, row.EpisodeNumber)
		watch, ok := byID[key]
		if !ok {
			watch = &EpisodeWatch{
				SeriesTMDBID:  row.SeriesTMDBID,
				SeriesTitle:   row.SeriesTitle,
				SeasonNumber:  row.SeasonNumber,
				EpisodeNumber: row.EpisodeNumber,
			}
			byID[key] = watch
		}
		watch.PlayCount++
		if row.Watched.Valid {
			watch.WatchDates = append(watch.WatchDates, row.Watched.Time)
			if watch.LastWatched == nil || row.Watched.Time.After(*watch.LastWatched) {
				value := row.Watched.Time
				watch.LastWatched = &value
			}
		}
	}
	result := make([]EpisodeWatch, 0, len(byID))
	for _, watch := range byID {
		sort.Slice(watch.WatchDates, func(i, j int) bool { return watch.WatchDates[i].Before(watch.WatchDates[j]) })
		result = append(result, *watch)
	}
	sort.Slice(result, func(i, j int) bool {
		left := fmt.Sprintf("%s:%09d:%09d", result[i].SeriesTitle, result[i].SeasonNumber, result[i].EpisodeNumber)
		right := fmt.Sprintf("%s:%09d:%09d", result[j].SeriesTitle, result[j].SeasonNumber, result[j].EpisodeNumber)
		return moreRecent(result[i].LastWatched, result[j].LastWatched, left, right)
	})
	return result
}

func moreRecent(left, right *time.Time, leftTie, rightTie string) bool {
	if left == nil && right == nil {
		return leftTie < rightTie
	}
	if left == nil {
		return false
	}
	if right == nil {
		return true
	}
	if left.Equal(*right) {
		return leftTie < rightTie
	}
	return left.After(*right)
}

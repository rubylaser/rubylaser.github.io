package provider

import (
	"fmt"
	"strconv"
	"strings"

	pluginv1 "github.com/Silo-Server/silo-plugin-sdk/pkg/pluginproto/silo/plugin/v1"
	"github.com/example/silo-plugin-yamtrack/internal/yamtrack"
)

const capabilityID = "yamtrack"

func databaseConfig(config *pluginv1.WatchSyncProviderConfig, password string) (yamtrack.Config, error) {
	values := map[string]string{}
	if config != nil {
		values = config.GetValues()
	}
	port, err := configInt(values, "yamtrack.port", 5432)
	if err != nil {
		return yamtrack.Config{}, err
	}
	userID, err := configInt64(values, "yamtrack.user_id", 1)
	if err != nil {
		return yamtrack.Config{}, err
	}
	password = strings.TrimSpace(password)
	if password == "" {
		return yamtrack.Config{}, fmt.Errorf("read-only PostgreSQL password is required")
	}
	return yamtrack.Config{
		Host:     configString(values, "yamtrack.host", "yamtrack-db"),
		Port:     port,
		Database: configString(values, "yamtrack.database", "yamtrack"),
		User:     configString(values, "yamtrack.user", "silo_sync"),
		Password: password,
		SSLMode:  configString(values, "yamtrack.sslmode", "disable"),
		UserID:   userID,
	}, nil
}

func configString(values map[string]string, key, fallback string) string {
	if value := strings.TrimSpace(values[key]); value != "" {
		return value
	}
	return fallback
}

func configInt(values map[string]string, key string, fallback int) (int, error) {
	value := strings.TrimSpace(values[key])
	if value == "" {
		return fallback, nil
	}
	parsed, err := strconv.Atoi(value)
	if err != nil || parsed < 1 || parsed > 65535 {
		return 0, fmt.Errorf("%s must be an integer between 1 and 65535", key)
	}
	return parsed, nil
}

func configInt64(values map[string]string, key string, fallback int64) (int64, error) {
	value := strings.TrimSpace(values[key])
	if value == "" {
		return fallback, nil
	}
	parsed, err := strconv.ParseInt(value, 10, 64)
	if err != nil || parsed < 1 {
		return 0, fmt.Errorf("%s must be a positive integer", key)
	}
	return parsed, nil
}

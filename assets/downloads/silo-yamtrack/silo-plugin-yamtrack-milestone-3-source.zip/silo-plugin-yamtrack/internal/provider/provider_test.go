package provider

import (
	"testing"
	"time"

	pluginv1 "github.com/Silo-Server/silo-plugin-sdk/pkg/pluginproto/silo/plugin/v1"
	"github.com/example/silo-plugin-yamtrack/internal/yamtrack"
)

func TestDatabaseConfig(t *testing.T) {
	cfg, err := databaseConfig(&pluginv1.WatchSyncProviderConfig{Values: map[string]string{
		"yamtrack.host":    "db",
		"yamtrack.port":    "5433",
		"yamtrack.user_id": "7",
	}}, "password")
	if err != nil {
		t.Fatal(err)
	}
	if cfg.Host != "db" || cfg.Port != 5433 || cfg.UserID != 7 || cfg.User != "silo_sync" {
		t.Fatalf("unexpected config: %+v", cfg)
	}
}

func TestPageTokenRoundTrip(t *testing.T) {
	want := pageToken{Cutoff: time.Now().UTC().Add(-time.Minute).Truncate(time.Nanosecond), After: "movie:tmdb:550"}
	encoded, err := encodePageToken(want)
	if err != nil {
		t.Fatal(err)
	}
	got, err := decodePageToken(encoded)
	if err != nil {
		t.Fatal(err)
	}
	if !got.Cutoff.Equal(want.Cutoff) || got.After != want.After {
		t.Fatalf("got %+v, want %+v", got, want)
	}
}

func TestRemoteStateMovie(t *testing.T) {
	when := time.Date(2026, 8, 6, 20, 33, 0, 0, time.UTC)
	state := remoteState(yamtrack.RemoteWatch{
		ProviderItemKey: "movie:tmdb:84575",
		MediaType:       "movie",
		TMDBID:          "84575",
		Title:           "Tooth Fairy 2",
		PlayCount:       6,
		LastWatched:     &when,
	})
	if state.GetMedia().GetMediaType() != pluginv1.WatchSyncMediaType_WATCH_SYNC_MEDIA_TYPE_MOVIE ||
		state.GetMedia().GetExternalIds()["tmdb"] != "84575" || state.GetWatched().GetPlayCount() != 6 {
		t.Fatalf("unexpected state: %+v", state)
	}
}

func TestRemoteStateEpisode(t *testing.T) {
	state := remoteState(yamtrack.RemoteWatch{
		ProviderItemKey: "episode:tmdb:20407:2:16",
		MediaType:       "episode",
		TMDBID:          "20407",
		Title:           "Chuggington",
		SeasonNumber:    2,
		EpisodeNumber:   16,
		PlayCount:       8,
	})
	media := state.GetMedia()
	if media.GetMediaType() != pluginv1.WatchSyncMediaType_WATCH_SYNC_MEDIA_TYPE_EPISODE ||
		media.GetSeriesExternalIds()["tmdb"] != "20407" || media.GetSeasonNumber() != 2 || media.GetEpisodeNumber() != 16 {
		t.Fatalf("unexpected media: %+v", media)
	}
}

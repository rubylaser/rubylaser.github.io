package provider

import (
	"context"
	"errors"
	"fmt"
	"math"
	"strings"
	"time"

	pluginv1 "github.com/Silo-Server/silo-plugin-sdk/pkg/pluginproto/silo/plugin/v1"
	"github.com/example/silo-plugin-yamtrack/internal/yamtrack"
	"github.com/jackc/pgx/v5/pgconn"
	"google.golang.org/protobuf/types/known/timestamppb"
)

type Server struct {
	pluginv1.UnimplementedWatchSyncProviderServer
}

func New() *Server { return &Server{} }

func (s *Server) ExchangeAPIKey(ctx context.Context, req *pluginv1.WatchSyncExchangeAPIKeyRequest) (*pluginv1.WatchSyncCredentialResponse, error) {
	if req.GetCapabilityId() != capabilityID {
		return &pluginv1.WatchSyncCredentialResponse{Fault: invalidRequest("unknown watch-sync capability")}, nil
	}
	cfg, err := databaseConfig(req.GetProviderConfig(), req.GetApiKey())
	if err != nil {
		return &pluginv1.WatchSyncCredentialResponse{Fault: invalidRequest(err.Error())}, nil
	}
	if fault := validateConnection(ctx, cfg); fault != nil {
		return &pluginv1.WatchSyncCredentialResponse{Fault: fault}, nil
	}
	return &pluginv1.WatchSyncCredentialResponse{
		Credentials: credentials(req.GetApiKey()),
		Account:     account(cfg.UserID),
	}, nil
}

func (s *Server) RefreshCredentials(ctx context.Context, req *pluginv1.WatchSyncRefreshCredentialsRequest) (*pluginv1.WatchSyncCredentialResponse, error) {
	requestContext := req.GetContext()
	if requestContext.GetCapabilityId() != capabilityID {
		return &pluginv1.WatchSyncCredentialResponse{Fault: invalidRequest("unknown watch-sync capability")}, nil
	}
	password := requestContext.GetCredentials().GetAccessToken()
	cfg, err := databaseConfig(requestContext.GetProviderConfig(), password)
	if err != nil {
		return &pluginv1.WatchSyncCredentialResponse{Fault: invalidRequest(err.Error())}, nil
	}
	if fault := validateConnection(ctx, cfg); fault != nil {
		return &pluginv1.WatchSyncCredentialResponse{Fault: fault}, nil
	}
	return &pluginv1.WatchSyncCredentialResponse{Credentials: credentials(password), Account: account(cfg.UserID)}, nil
}

func (s *Server) GetAccount(ctx context.Context, req *pluginv1.WatchSyncGetAccountRequest) (*pluginv1.WatchSyncGetAccountResponse, error) {
	requestContext := req.GetContext()
	if requestContext.GetCapabilityId() != capabilityID {
		return &pluginv1.WatchSyncGetAccountResponse{Fault: invalidRequest("unknown watch-sync capability")}, nil
	}
	cfg, err := databaseConfig(requestContext.GetProviderConfig(), requestContext.GetCredentials().GetAccessToken())
	if err != nil {
		return &pluginv1.WatchSyncGetAccountResponse{Fault: invalidRequest(err.Error())}, nil
	}
	if fault := validateConnection(ctx, cfg); fault != nil {
		return &pluginv1.WatchSyncGetAccountResponse{Fault: fault}, nil
	}
	return &pluginv1.WatchSyncGetAccountResponse{Account: account(cfg.UserID)}, nil
}

func (s *Server) ApplyEvents(context.Context, *pluginv1.WatchSyncApplyEventsRequest) (*pluginv1.WatchSyncApplyEventsResponse, error) {
	return &pluginv1.WatchSyncApplyEventsResponse{
		Fault: invalidRequest("Yamtrack export is disabled; this provider is import-only"),
	}, nil
}

func (s *Server) ListRemoteState(ctx context.Context, req *pluginv1.WatchSyncListRemoteStateRequest) (*pluginv1.WatchSyncListRemoteStateResponse, error) {
	requestContext := req.GetContext()
	if requestContext.GetCapabilityId() != capabilityID {
		return &pluginv1.WatchSyncListRemoteStateResponse{Fault: invalidRequest("unknown watch-sync capability")}, nil
	}
	if !requestsWatched(req.GetStateKinds()) {
		return &pluginv1.WatchSyncListRemoteStateResponse{
			CompleteSnapshot: true,
			NextCursor:       time.Now().UTC().Format(time.RFC3339Nano),
		}, nil
	}

	cfg, err := databaseConfig(requestContext.GetProviderConfig(), requestContext.GetCredentials().GetAccessToken())
	if err != nil {
		return &pluginv1.WatchSyncListRemoteStateResponse{Fault: invalidRequest(err.Error())}, nil
	}

	pageSize := int(req.GetPageSize())
	if pageSize < 1 {
		pageSize = yamtrack.MaxRemotePageSize
	}
	if pageSize > yamtrack.MaxRemotePageSize {
		pageSize = yamtrack.MaxRemotePageSize
	}
	token := pageToken{Cutoff: time.Now().UTC()}
	if strings.TrimSpace(req.GetPageToken()) != "" {
		token, err = decodePageToken(req.GetPageToken())
		if err != nil {
			return &pluginv1.WatchSyncListRemoteStateResponse{Fault: invalidRequest(err.Error())}, nil
		}
	}

	store, err := yamtrack.Open(ctx, cfg)
	if err != nil {
		return &pluginv1.WatchSyncListRemoteStateResponse{Fault: databaseFault(err)}, nil
	}
	defer store.Close()
	rows, err := store.WatchedPage(ctx, cfg.UserID, token.Cutoff, token.After, pageSize+1)
	if err != nil {
		return &pluginv1.WatchSyncListRemoteStateResponse{Fault: databaseFault(err)}, nil
	}

	hasMore := len(rows) > pageSize
	if hasMore {
		rows = rows[:pageSize]
	}
	response := &pluginv1.WatchSyncListRemoteStateResponse{
		Items:            make([]*pluginv1.WatchSyncRemoteState, 0, len(rows)),
		CompleteSnapshot: true,
	}
	for _, row := range rows {
		response.Items = append(response.Items, remoteState(row))
	}
	if hasMore {
		next, err := encodePageToken(pageToken{Cutoff: token.Cutoff, After: rows[len(rows)-1].ProviderItemKey})
		if err != nil {
			return &pluginv1.WatchSyncListRemoteStateResponse{Fault: temporary("could not continue Yamtrack pagination")}, nil
		}
		response.NextPageToken = next
	} else {
		response.NextCursor = token.Cutoff.Format(time.RFC3339Nano)
	}
	return response, nil
}

func validateConnection(ctx context.Context, cfg yamtrack.Config) *pluginv1.WatchSyncFault {
	store, err := yamtrack.Open(ctx, cfg)
	if err != nil {
		return databaseFault(err)
	}
	defer store.Close()
	if err := store.VerifySchema(ctx); err != nil {
		return databaseFault(err)
	}
	if err := store.ValidateUser(ctx, cfg.UserID); err != nil {
		return invalidRequest("configured Yamtrack user ID has no tracked media")
	}
	return nil
}

func credentials(password string) *pluginv1.WatchSyncCredentials {
	return &pluginv1.WatchSyncCredentials{AccessToken: password, TokenType: "PostgreSQL password"}
}

func account(userID int64) *pluginv1.WatchSyncAccount {
	return &pluginv1.WatchSyncAccount{
		ExternalSubject: fmt.Sprintf("yamtrack:%d", userID),
		Username:        fmt.Sprintf("Yamtrack user %d", userID),
		DisplayName:     fmt.Sprintf("Yamtrack user %d", userID),
	}
}

func requestsWatched(kinds []pluginv1.WatchSyncRemoteStateKind) bool {
	if len(kinds) == 0 {
		return true
	}
	for _, kind := range kinds {
		if kind == pluginv1.WatchSyncRemoteStateKind_WATCH_SYNC_REMOTE_STATE_KIND_WATCHED {
			return true
		}
	}
	return false
}

func remoteState(watch yamtrack.RemoteWatch) *pluginv1.WatchSyncRemoteState {
	playCount := watch.PlayCount
	if playCount > math.MaxInt32 {
		playCount = math.MaxInt32
	}
	media := &pluginv1.WatchSyncMedia{Title: watch.Title}
	switch watch.MediaType {
	case "movie":
		media.MediaType = pluginv1.WatchSyncMediaType_WATCH_SYNC_MEDIA_TYPE_MOVIE
		media.ExternalIds = map[string]string{"tmdb": watch.TMDBID}
	case "episode":
		media.MediaType = pluginv1.WatchSyncMediaType_WATCH_SYNC_MEDIA_TYPE_EPISODE
		media.SeriesTitle = watch.Title
		media.SeriesExternalIds = map[string]string{"tmdb": watch.TMDBID}
		media.SeasonNumber = int32(watch.SeasonNumber)
		media.EpisodeNumber = int32(watch.EpisodeNumber)
	}
	state := &pluginv1.WatchSyncRemoteState{
		ProviderItemKey: watch.ProviderItemKey,
		Media:           media,
		Watched:         &pluginv1.WatchSyncRemoteWatchedState{PlayCount: int32(playCount)},
	}
	if watch.LastWatched != nil {
		state.Watched.LastWatchedAt = timestamppb.New(*watch.LastWatched)
	}
	return state
}

func databaseFault(err error) *pluginv1.WatchSyncFault {
	var pgError *pgconn.PgError
	if errors.As(err, &pgError) {
		switch pgError.Code {
		case "28P01":
			return fault(pluginv1.WatchSyncFaultCode_WATCH_SYNC_FAULT_CODE_INVALID_CREDENTIAL, "Yamtrack rejected the read-only PostgreSQL password")
		case "42501":
			return fault(pluginv1.WatchSyncFaultCode_WATCH_SYNC_FAULT_CODE_PERMISSION_DENIED, "The Yamtrack PostgreSQL role lacks required read access")
		}
	}
	return temporary("Yamtrack PostgreSQL is temporarily unavailable or its schema is incompatible")
}

func invalidRequest(message string) *pluginv1.WatchSyncFault {
	return fault(pluginv1.WatchSyncFaultCode_WATCH_SYNC_FAULT_CODE_INVALID_REQUEST, message)
}

func temporary(message string) *pluginv1.WatchSyncFault {
	return fault(pluginv1.WatchSyncFaultCode_WATCH_SYNC_FAULT_CODE_TEMPORARY, message)
}

func fault(code pluginv1.WatchSyncFaultCode, message string) *pluginv1.WatchSyncFault {
	return &pluginv1.WatchSyncFault{Code: code, SafeMessage: message}
}

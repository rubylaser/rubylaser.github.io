package provider

import (
	"encoding/base64"
	"encoding/json"
	"fmt"
	"strings"
	"time"
)

type pageToken struct {
	Cutoff time.Time `json:"cutoff"`
	After  string    `json:"after"`
}

func encodePageToken(token pageToken) (string, error) {
	data, err := json.Marshal(token)
	if err != nil {
		return "", fmt.Errorf("encode page token: %w", err)
	}
	return base64.RawURLEncoding.EncodeToString(data), nil
}

func decodePageToken(value string) (pageToken, error) {
	data, err := base64.RawURLEncoding.DecodeString(strings.TrimSpace(value))
	if err != nil {
		return pageToken{}, fmt.Errorf("page token is invalid")
	}
	var token pageToken
	if err := json.Unmarshal(data, &token); err != nil || token.Cutoff.IsZero() || strings.TrimSpace(token.After) == "" {
		return pageToken{}, fmt.Errorf("page token is invalid")
	}
	if token.Cutoff.After(time.Now().UTC().Add(5 * time.Minute)) {
		return pageToken{}, fmt.Errorf("page token cutoff is invalid")
	}
	return token, nil
}

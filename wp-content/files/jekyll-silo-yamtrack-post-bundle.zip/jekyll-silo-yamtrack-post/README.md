# Jekyll publication bundle

Copy `_posts/` and `assets/` into the root of your Jekyll site while preserving their paths.

The post uses standard Jekyll YAML front matter and `relative_url` for images and downloads. Before publishing:

1. Confirm that your theme uses `layout: post`; change it if necessary.
2. Adjust the title, date, categories, tags, excerpt, and image fields to match your site's conventions.
3. Preview the site locally and verify both screenshots render.
4. Download each linked archive from the preview and verify its SHA-256 checksum.
5. Commit the binary downloads only if your Git host accepts files of their size. Otherwise, move them to a release/download host and replace the three post links.

Bundle layout:

```text
_posts/
  2026-08-07-import-yamtrack-watch-history-into-silo.md
assets/
  downloads/silo-yamtrack/
    silo-yamtrack-watchsync-linux-amd64.zip
    silo-yamtrack-watchsync-linux-arm64.zip
    silo-plugin-yamtrack-milestone-3-source.zip
  images/posts/silo-yamtrack/
    yamtrack-connected-before-sync.jpg
    yamtrack-sync-complete.jpg
```
